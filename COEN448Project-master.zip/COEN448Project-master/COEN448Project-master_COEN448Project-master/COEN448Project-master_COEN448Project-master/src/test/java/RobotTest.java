import org.example.Robot;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertArrayEquals;
import static org.junit.jupiter.api.Assertions.assertEquals;

public class RobotTest {

    private Robot robot;

    @BeforeEach
    public void setUp() {
        robot = new Robot(3); 
    }

    @Test
    public void testRobotPosition() {
        int[] position = robot.RobotPosition();
        assertEquals(2, position[0]);
        assertEquals(0, position[1]);
        robot = new Robot(5);
        position = robot.RobotPosition();
        assertEquals(4, position[0]);
        assertEquals(0, position[1]);
    }

    @Test
    public void testRobotUpdatePosition() {
        robot.RobotUpdatePosition(1, 2);
        int[] position = robot.RobotPosition();
        assertEquals(1, position[0]);
        assertEquals(2, position[1]);

        int[] prevPosition = robot.getRobotPreviousPosition();
        assertArrayEquals(new int[]{2, 0}, prevPosition);

        robot.RobotUpdatePosition(0, 4);
        position = robot.RobotPosition();
        assertEquals(0, position[0]);
        assertEquals(4, position[1]);

        prevPosition = robot.getRobotPreviousPosition();
        assertArrayEquals(new int[]{1, 2}, prevPosition);
    }
}