import org.example.Commands;
import org.example.Robot;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;
import java.io.ByteArrayOutputStream;
import java.io.PrintStream;
import java.util.ArrayList;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.Mockito.*;

public class CommandsTest {

    private Commands commands;
    private Robot mockRobot;
    private ByteArrayOutputStream outputStream;

    @BeforeEach
    public void setUp() {
        commands = new Commands("i");
        commands.setBipbop(new Robot(5));
    }

    @Test
    public void testTurnLeft() {
        commands.setTurnLeft(true);
        assertTrue(commands.isTurnWest());
        assertFalse(commands.isTurnNorth());
        assertFalse(commands.isTurnSouth());
        assertFalse(commands.isTurnEast());
        assertEquals("West", commands.PenDirection);
    }
    
    @Test
    public void testTurnRight() {
        commands.setTurnRight(true);
        assertTrue(commands.isTurnEast());
        assertFalse(commands.isTurnNorth());
        assertFalse(commands.isTurnSouth());
        assertFalse(commands.isTurnWest());
        assertEquals("East", commands.PenDirection);
    }

    @Test
    public void testPenUp() {
        commands.setPenUp(true);
        assertTrue(commands.isPenUp());
        assertFalse(commands.isPenDown());
    }

    @Test
    public void testPenStatusWhenPenIsUp() {
        commands.setPenDown(false);
        commands.setPenUp(true);
        assertTrue(commands.isPenUp());
        assertFalse(commands.isPenDown());
    }

    @Test
    public void testPenStatusWhenPenIsUp_Mutation() {
        commands.setPenDown(false);
        commands.setPenUp(false);
        assertFalse(commands.isPenUp());
        assertFalse(commands.isPenDown());
    }
    
    @Test
    public void testPenStatusWhenPenIsUp_Mutation1() {
        commands.setPenDown(true);
        commands.setPenUp(false);
        assertFalse(commands.isPenUp());
        assertTrue(commands.isPenDown());
    }
    
    @Test
    public void testPenStatusWhenPenIsUp_Mutation2() {
        commands.setPenDown(true);
        commands.setPenUp(true);
        assertTrue(commands.isPenUp());
        assertTrue(commands.isPenDown());
    }
    
    @Test
    public void testPenStatusWhenPenIsDown() {
        commands.setPenDown(true);
        commands.setPenUp(false);
        assertTrue(commands.isPenDown());
        assertFalse(commands.isPenUp());
    }

    @Test
    public void testPenStatusWhenBothPenStatesAreTheSame() {
        commands.setPenDown(true);
        commands.setPenUp(true);
        assertTrue(commands.isPenDown());
        assertTrue(commands.isPenUp());
    }

    @Test
    public void testPrintArray() {
        commands.InitializeArray(3);
        commands.setPenDown(true);
        commands.MoveForward(2);
        commands.setTurnRight(true);
        commands.MovetoRight(2);
        commands.setPenUp(true);
        commands.MoveForward(1);

        // Since we've executed some movements with the pen down, the array should contain "*" in those positions.
        assertTrue(commands.x.get(0).contains("*"));
        assertTrue(commands.x.get(1).contains("*"));
        assertEquals(" ", commands.x.get(2).get(2));
    }

    @Test
    public void testInitializeArray() {
        commands.InitializeArray(5);
        assertEquals(5, commands.x.size());
        assertEquals(5, commands.x.get(0).size());
    }

        @Test
        public void testPenUpNoDrawing() {
            commands.InitializeArray(3);
            commands.setPenUp(true);
            commands.MoveForward(1);

            // Assert there's no drawing as the pen was up.
            assertEquals(" ", commands.x.get(0).get(0));
            assertEquals(" ", commands.x.get(0).get(1));
            assertEquals(" ", commands.x.get(0).get(2));
        }

        @Test
        public void testCommandInitialization() {
            Commands newCommands = new Commands("r");
            assertEquals("r", newCommands.getCommand());
        }
        
        @Test
        public void testCommandInitialization1() {
            Commands newCommands = new Commands("D");
            assertEquals("D", newCommands.getCommand());
        }
        
        @Test
        public void testCommandInitialization2() {
            Commands newCommands = new Commands("u");
            assertEquals("u", newCommands.getCommand());
        }
        
        @Test
        public void testSetBipbop() {
            Robot robot = new Robot(7);
            commands.setBipbop(robot);
            assertEquals(robot, commands.getBipbop());
        }

        @Test
        public void testGetBipbop() {
            Robot robot = new Robot(8);
            commands.setBipbop(robot);
            Robot result = commands.getBipbop();
            assertEquals(robot, result);
        }
        
        
        @Test
        public void testRobotPositionWest()
        {
            Commands testCommand=new Commands("i");
            testCommand.InitializeArray(10);
            testCommand.setTurnRight(true);
            assertEquals("East",testCommand.PenDirection);
            testCommand.MovetoRight(2);

            testCommand.setTurnLeft(true);
            assertEquals("North",testCommand.PenDirection);
            testCommand.MoveForward(3);
            testCommand.setTurnLeft(true);
            assertEquals("West",testCommand.PenDirection);
            testCommand.MovetoLeft(2);

            assertEquals(4,(10-testCommand.getBipbop().posx));
            //assertEquals(1,testCommand.getBipbop().posy);

        }



        @Test
        public void testRobotPositionSouth()
        {
            Commands testCommand=new Commands("i");
            testCommand.InitializeArray(6);
            testCommand.MoveForward(3);
            testCommand.setTurnRight(true);
            testCommand.MovetoRight(4);

            testCommand.MovetoRight(2);
            assertEquals(4,(6-testCommand.getBipbop().posx));
            assertEquals(0,testCommand.getBipbop().posy);
        }


        @Test
        public void testOutOfBoundsMovetoRight() {
            Commands testCommand = new Commands("i");
            testCommand.InitializeArray(6);

            // Move the robot to the right beyond the array bounds
            testCommand.MovetoRight(8);

            // Verify that the robot position is at the rightmost boundary
            assertEquals(5, testCommand.getBipbop().posx);
            assertEquals(0, testCommand.getBipbop().posy);
        }

        @Test
        public void testOutOfBoundsMovetoLeft() {
            Commands testCommand = new Commands("i");
            testCommand.InitializeArray(6);

            // Move the robot to the left beyond the array bounds
            testCommand.MovetoLeft(8);

            // Verify that the robot position is at the leftmost boundary
            assertEquals(5, testCommand.getBipbop().posx);
            assertEquals(0, testCommand.getBipbop().posy);
        }

        @Test
        public void testOutOfBoundsMoveForward() {
            Commands testCommand = new Commands("i");
            testCommand.InitializeArray(6);

            // Move the robot forward beyond the array bounds
            testCommand.MoveForward(8);

            // Verify that the robot position is at the upper boundary
            assertEquals(0, testCommand.getBipbop().posx);
            assertEquals(0, testCommand.getBipbop().posy);
        }

        @Test
        public void testOutOfBoundsMoveBackwards() {
            Commands testCommand = new Commands("i");
            testCommand.InitializeArray(6);

            // Turn the robot south
            testCommand.setTurnRight(true);
            testCommand.setTurnRight(true);

            // Move the robot backward beyond the array bounds
            testCommand.MoveBackwards(8);

            // Verify that the robot position is at the lower boundary
            assertEquals(5, testCommand.getBipbop().posx);
            assertEquals(0, testCommand.getBipbop().posy);
        }


        @Test
        public void testTurnRightAndLeft() {
            Commands testCommand = new Commands("i");
            testCommand.InitializeArray(6);

            // Initially, the robot is facing North
            assertEquals("North", testCommand.PenDirection);

            // Turn the robot right
            testCommand.setTurnRight(true);
            assertEquals("East", testCommand.PenDirection);

            // Turn the robot left
            testCommand.setTurnLeft(true);
            assertEquals("North", testCommand.PenDirection);

            // Turn the robot left again
            testCommand.setTurnLeft(true);
            assertEquals("West", testCommand.PenDirection);

            // Turn the robot right
            testCommand.setTurnRight(true);
            assertEquals("North", testCommand.PenDirection);
        }

        
        
        @Test
        public void testMoveToRightWhenPenUp() {
            commands.InitializeArray(3);
            commands.setPenUp(true);
            commands.MovetoRight(1);

            assertEquals(" ", commands.x.get(0).get(0));
        }

        @Test
        public void testMoveForwardWhenPenUp() {
            commands.InitializeArray(3);
            commands.setPenUp(true);
            commands.MoveForward(1);
            assertEquals(" ", commands.x.get(0).get(0));
        }
        
        //@Test
        public void testMoveForwardWhenPenUp_Mutation_ChangeAssert() {
            commands.InitializeArray(3);
            commands.setPenUp(false);
            commands.MoveForward(1);
            assertNotEquals(" ", commands.x.get(0).get(0)); // Negate the condition to trigger mutation
        }

        //@Test
        public void testMoveForwardWhenPenDown_Mutation_ChangeAssert() {
            Commands testCommand = new Commands("i");
            testCommand.InitializeArray(3);
            testCommand.setPenDown(true);
            testCommand.MoveForward(1);
            assertEquals("*", testCommand.x.get(0).get(0)); // Change to a different symbol to trigger mutation
        }
        
        @Test
        public void testMoveForwardWhenPenDown() {
        	Commands testCommand = new Commands("i");
        	testCommand.InitializeArray(3);
        	testCommand.setPenDown(true);
        	testCommand.MoveForward(1);
        }
        
        @Test
        public void testMoveBackwardsWhenPenDown() {
        	Commands testCommand = new Commands("i");
        	testCommand.InitializeArray(3);
        	testCommand.MoveForward(1);
        	testCommand.setPenDown(true);
        	testCommand.MoveBackwards(1);
        	assertEquals("*", testCommand.x.get(1).get(0));
        }
        
        
        @Test
        public void testTurnRightTwice() {
            commands.setTurnRight(true);
            commands.setTurnRight(true);
            assertTrue(commands.isTurnSouth());
            assertFalse(commands.isTurnNorth());
            assertFalse(commands.isTurnWest());
            assertFalse(commands.isTurnEast());
            assertEquals("South", commands.PenDirection);
        }

        @Test
        public void testTurnLeftTwice() {
            commands.setTurnLeft(true);
            commands.setTurnLeft(true);
            assertTrue(commands.isTurnSouth());
            assertFalse(commands.isTurnNorth());
            assertFalse(commands.isTurnWest());
            assertFalse(commands.isTurnEast());
            assertEquals("South", commands.PenDirection);
        }

        @Test
        public void testInitializeArrayWithDifferentSize() {
            commands.InitializeArray(4);
            assertEquals(4, commands.x.size());
            assertEquals(4, commands.x.get(0).size());
        }

        @Test
        public void testNoDuplicateStarsAfterMoving() {
            commands.InitializeArray(3);
            commands.setPenDown(true);
            commands.MoveForward(1);
            commands.setTurnRight(true);
            commands.MoveForward(1);
            commands.setTurnRight(true);
            commands.MoveForward(1);
            int starCount = 0;
            for (ArrayList<String> row : commands.x) {
                for (String cell : row) {
                    if (cell.equals("*")) {
                        starCount++;
                    }
                }
            }
            assertEquals(3, starCount);
        }
        

        @Test
        public void testMoveToRightBeyondArray() {
            commands.InitializeArray(3);
            commands.setPenDown(true);
            commands.MovetoRight(5);

            // Since the array size is 3, it should not contain a drawing at index 5.
            assertThrows(IndexOutOfBoundsException.class, () -> commands.x.get(0).get(5));
        }

        @Test
        public void testMoveForwardBeyondArray() {
            commands.InitializeArray(3);
            commands.setPenDown(true);
            commands.MoveForward(5);

            // Since the array size is 3, it should not contain a drawing at index 5.
            assertThrows(IndexOutOfBoundsException.class, () -> commands.x.get(5).get(0));
        }

        @Test
        public void testMoveBackwardBeyondArray() {
            commands.InitializeArray(3);
            commands.setPenDown(true);
            commands.MoveBackwards(5);

            // Since the array size is 3, it should not contain a drawing at index 5.
            assertThrows(IndexOutOfBoundsException.class, () -> commands.x.get(5).get(0));
        }
        
        @Test
        public void testMultipleTurnsRight() {
            commands.setTurnRight(true);
            commands.setTurnRight(true);
            commands.setTurnRight(true);
            commands.setTurnRight(true);

            // After 4 turns to the right, it should be facing the original direction (North).
            assertTrue(commands.isTurnNorth());
            assertEquals("North", commands.PenDirection);
        }

        @Test
        public void testMultipleTurnsLeft() {
            commands.setTurnLeft(true);
            commands.setTurnLeft(true);
            commands.setTurnLeft(true);
            commands.setTurnLeft(true);

            // After 4 turns to the left, it should be facing the original direction (North).
            assertTrue(commands.isTurnNorth());
            assertEquals("North", commands.PenDirection);
        }


        @Test
        public void testMoveBackwardsWhenPenUp() {
            commands.InitializeArray(3);
            commands.setPenUp(true);
            commands.MoveBackwards(1);

            // As the pen was up, no drawing should be made.
            assertEquals(" ", commands.x.get(0).get(0));
        }
        
        @BeforeEach
        public void setUp1() {
            commands = new Commands("i");
            commands.InitializeArray(3);
            commands.setBipbop(new Robot(3));
            commands.setPenUp(true); 
        }
        
        @Test
        public void testSetTurnRightFacingNorth() {
            assertTrue(commands.isTurnNorth());
            assertFalse(commands.isTurnEast());
            assertFalse(commands.isTurnWest());
            assertFalse(commands.isTurnSouth());
            commands.setTurnRight(true);
            assertFalse(commands.isTurnNorth());
            assertTrue(commands.isTurnEast());
            assertFalse(commands.isTurnWest());
            assertFalse(commands.isTurnSouth());
            assertEquals("East", commands.PenDirection);
        }

        @Test
        public void testSetTurnRightFacingSouth() {
            assertTrue(commands.isTurnNorth());
            assertFalse(commands.isTurnEast());
            assertFalse(commands.isTurnWest());
            assertFalse(commands.isTurnSouth());
            commands.setTurnRight(true);
            commands.setTurnRight(true);
            assertFalse(commands.isTurnNorth());
            assertFalse(commands.isTurnEast());
            assertFalse(commands.isTurnWest());
            assertTrue(commands.isTurnSouth());
            assertEquals("South", commands.PenDirection);
        }
        
        @Test
        public void testSetTurnLeftFacingNorth() {
            assertTrue(commands.isTurnNorth());
            assertFalse(commands.isTurnEast());
            assertFalse(commands.isTurnWest());
            assertFalse(commands.isTurnSouth());
            commands.setTurnLeft(true);
            assertFalse(commands.isTurnNorth());
            assertFalse(commands.isTurnEast());
            assertTrue(commands.isTurnWest());
            assertFalse(commands.isTurnSouth());
            assertEquals("West", commands.PenDirection);
        }

        @Test
        public void testSetTurnLeftFacingSouth() {
            assertTrue(commands.isTurnNorth());
            assertFalse(commands.isTurnEast());
            assertFalse(commands.isTurnWest());
            assertFalse(commands.isTurnSouth());
            commands.setTurnLeft(true);
            commands.setTurnLeft(true);
            assertFalse(commands.isTurnNorth());
            assertFalse(commands.isTurnEast());
            assertFalse(commands.isTurnWest());
            assertTrue(commands.isTurnSouth());
            assertEquals("South", commands.PenDirection);
        }
        @BeforeEach
        public void setUp2() {
            commands = new Commands("");
            mockRobot = mock(Robot.class);
            commands.setBipbop(mockRobot);
            outputStream = new ByteArrayOutputStream();
            System.setOut(new PrintStream(outputStream));
        }
        
        @SuppressWarnings("null")
		@Test
        public void testSetPenUpOnNullCommandsObject() {
            Commands commands = null;
            // Attempt to call setPenUp on a null object
            assertThrows(NullPointerException.class, () -> {
                commands.setPenUp(true);
            });
        }
        
        @SuppressWarnings("null")
		@Test
        public void testInitializeArrayOnNullCommandsObject() {
            Commands commands = null;
            // Attempt to call InitializeArray on a null object
            assertThrows(NullPointerException.class, () -> {
                commands.InitializeArray(3);
            });
        }

    }



