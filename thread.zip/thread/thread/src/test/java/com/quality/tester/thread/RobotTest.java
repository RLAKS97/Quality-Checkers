package com.quality.tester.thread;


import static org.junit.Assert.*;
import org.junit.*;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.io.PrintStream;


public class RobotTest{

    
    private String[][] robotMap;
    private int nMatrix;
    private String[] commandArray;
    private int[] robotPosition;



    @Test
    public void testChangeRobotFaceLeft() {
    	
        String currentFace = "north";
        String expectedFace = "west";
        assertEquals(expectedFace, com.quality.tester.thread.Robot.changeRobotFaceLeft(currentFace));
    }

    @Test
    public void testChangeRobotFaceRight() {
        String currentFace = "north";
        String expectedFace = "east";
        assertEquals(expectedFace, Robot.changeRobotFaceRight(currentFace));
    }
    
    @Test
    public void testChangeRobotFaceLeftFromWest() {
        String currentFace = "west";
        String expectedFace = "south";
        assertEquals(expectedFace, Robot.changeRobotFaceLeft(currentFace));
    }

    @Test
    public void testChangeRobotFaceRightFromWest() {
        String currentFace = "west";
        String expectedFace = "north";
        assertEquals(expectedFace, Robot.changeRobotFaceRight(currentFace));
    }
    
    @Test
    public void testChangeRobotFaceLeftFromSouth() {
        String currentFace = "south";
        String expectedFace = "east";
        assertEquals(expectedFace, Robot.changeRobotFaceLeft(currentFace));
    }
    
    @Test
    public void testChangeRobotFaceRightFromSouth() {
        String currentFace = "south";
        String expectedFace = "west";
        assertEquals(expectedFace, Robot.changeRobotFaceRight(currentFace));
    }
    
    @Test
    public void testChangeRobotFaceLeftFromEast() {
        String currentFace = "east";
        String expectedFace = "north";
        assertEquals(expectedFace, Robot.changeRobotFaceLeft(currentFace));
    }
    
    @Test
    public void testChangeRobotFaceRightFromEast() {
        String currentFace = "east";
        String expectedFace = "south";
        assertEquals(expectedFace, Robot.changeRobotFaceRight(currentFace));
    }
    
    @Test
    public void testChangeRobotFaceLeftMultipleTimes() {
        String currentFace = "north";
        currentFace = Robot.changeRobotFaceLeft(currentFace);
        currentFace = Robot.changeRobotFaceLeft(currentFace);
        currentFace = Robot.changeRobotFaceLeft(currentFace);
        String expectedFace = "east";
        assertEquals(expectedFace, currentFace);
    }

    @Test
    public void testChangeRobotFaceRightMultipleTimes() {
        String currentFace = "north";
        currentFace = Robot.changeRobotFaceRight(currentFace);
        currentFace = Robot.changeRobotFaceRight(currentFace);
        currentFace = Robot.changeRobotFaceRight(currentFace);
        String expectedFace = "west";
        assertEquals(expectedFace, currentFace);
    }
    
    @Test
    public void testFullRightRotation() {
        String currentFace = "north";
        currentFace = Robot.changeRobotFaceRight(currentFace);
        currentFace = Robot.changeRobotFaceRight(currentFace);
        currentFace = Robot.changeRobotFaceRight(currentFace);
        currentFace = Robot.changeRobotFaceRight(currentFace);
        assertEquals("north", currentFace);
    }
  
    @Test
    public void testFullLeftRotation() {
        String currentFace = "north";
        currentFace = Robot.changeRobotFaceLeft(currentFace);
        currentFace = Robot.changeRobotFaceLeft(currentFace);
        currentFace = Robot.changeRobotFaceLeft(currentFace);
        currentFace = Robot.changeRobotFaceLeft(currentFace);
        assertEquals("north", currentFace);
    }
    
    @Test
    public void testMove() {
        commandArray = new String[]{"m", "3"};
        int[] expectedPosition = new int[]{3, 0};  // assuming the robot faces north and moves 3 steps forward
        assertArrayEquals(expectedPosition, Robot.move(robotPosition, commandArray, nMatrix, "north", false, robotMap));
    }
    
    @Test
    public void testMoveWhileFacingEast() {
        commandArray = new String[]{"m", "2"};
        int[] expectedPosition = new int[]{0, 2}; 
        assertArrayEquals(expectedPosition, Robot.move(robotPosition, commandArray, nMatrix, "east", false, robotMap));
    }
    
    @Test
    public void testMoveWhileFacingWest() {
        robotPosition = new int[]{0, 2};
        commandArray = new String[]{"m", "2"};
        int[] expectedPosition = new int[]{0, 0}; 
        assertArrayEquals(expectedPosition, Robot.move(robotPosition, commandArray, nMatrix, "west", false, robotMap));
    }
    
    @Test
    public void testMoveWhileFacingNorth() {
        commandArray = new String[]{"m", "2"};
        int[] expectedPosition = new int[]{2, 0}; 
        assertArrayEquals(expectedPosition, Robot.move(robotPosition, commandArray, nMatrix, "north", false, robotMap));
    }
    @Test
    public void testMoveWhileFacingSouth() {
        robotPosition = new int[]{2, 0};
        commandArray = new String[]{"m", "2"};
        int[] expectedPosition = new int[]{0, 0}; 
        assertArrayEquals(expectedPosition, Robot.move(robotPosition, commandArray, nMatrix, "south", false, robotMap));
    }
    
    @Before
    public void setUp() {
        nMatrix = 5;
        robotPosition = new int[]{0, 0};
        robotMap = new String[nMatrix][nMatrix];
        Robot.initialiseArray(nMatrix);
    }
    
    @Test
    public void testInitialPosition() {
        assertArrayEquals(new int[]{0, 0}, robotPosition);
    }
    
    @Test
    public void testInitialPenDirection() {
        assertEquals(false, Robot.isPenDown);
    }

    @Test
    public void testInitialRobotFace() {
        assertEquals("north", Robot.robotFace);
    }

    @Test
    public void testInitialRobotPosition() {
        assertArrayEquals(new int[]{0, 0}, Robot.robotPosition);
    }
    
    @Test
    public void testMoveZeroSteps() {
        commandArray = new String[]{"m", "0"};
        int[] expectedPosition = new int[]{0, 0}; 
        assertArrayEquals(expectedPosition, Robot.move(robotPosition, commandArray, nMatrix, "north", false, robotMap));
    }
    
    @Test
    public void testMoveOutsideGrid() {
        commandArray = new String[]{"m", "6"};  // Trying to move the robot 6 steps, which exceeds the grid size (5)
        int[] expectedPosition = new int[]{0, 0};  // The robot should remain at the initial position
        assertArrayEquals(expectedPosition, Robot.move(robotPosition, commandArray, nMatrix, "north", false, robotMap));
    }
    
    @Test
    public void testMoveWithinGridBounds() {
        commandArray = new String[]{"m", "2"};
        int[] expectedPosition = new int[]{2, 0};  // Assuming the robot faces north and moves 2 steps forward
        assertArrayEquals(expectedPosition, Robot.move(robotPosition, commandArray, nMatrix, "north", false, robotMap));
    }

    @Test
    public void testMoveToGridBoundary() {
        commandArray = new String[]{"m", "5"};
        int[] expectedPosition = new int[]{5, 0};  // Assuming the robot faces north and moves 5 steps forward (reaches the grid boundary)
        assertArrayEquals(expectedPosition, Robot.move(robotPosition, commandArray, nMatrix, "north", false, robotMap));
    }

    @Test
    public void testChangeRobotFaceLeftFromInvalidDirection() {
        String currentFace = "invalid";
        String expectedFace = "north";  // The robot face should not change if the input is invalid
        assertEquals(expectedFace, Robot.changeRobotFaceLeft(currentFace));
    }

    
    @Test
    public void testTrackRobot() {
        Robot.initialiseArray(5);
        String[][] expectedMap = new String[5][5];
        expectedMap[2][2] = "*";
        Robot.trackRobot(2, 2, 2, 2, true, Robot.robotMap);
        assertArrayEquals(expectedMap, Robot.robotMap);
    }
    

    @Test
    public void testMoveWithPenUp() {
        Robot.initialiseArray(5);
        int[] startPosition = new int[]{0, 0};
        String[] commandArray = new String[]{"M", "3"};
        int[] expectedPosition = new int[]{3, 0};
        int[] newPosition = Robot.move(startPosition, commandArray, 5, "north", false, Robot.robotMap);
        assertArrayEquals(expectedPosition, newPosition);
        assertEquals(null, Robot.robotMap[3][0]); // Check if it did not mark the path
    }

    @Test
    public void testMoveWithPenDown() {
        Robot.initialiseArray(5);
        int[] startPosition = new int[]{0, 0};
        String[] commandArray = new String[]{"M", "3"};
        int[] expectedPosition = new int[]{3, 0};
        int[] newPosition = Robot.move(startPosition, commandArray, 5, "north", true, Robot.robotMap);
        assertArrayEquals(expectedPosition, newPosition);
        assertEquals("*", Robot.robotMap[0][3]); // Check if it did not mark the path
    }
    
    @Test
    public void testTrackRobotWithNegativeCoordinates() {
        Robot.initialiseArray(5);
        String[][] expectedMap = new String[5][5]; // Map should not change
        Robot.trackRobot(-1, -1, -1, -1, false, Robot.robotMap); // Invalid coordinates
        assertArrayEquals(expectedMap, Robot.robotMap);
    }
    
    //@Test
    public void testMainMethod() {
        String input = "I 3\nM 2\nQ\n";
        String expectedOutput = "Welcome to RoboticPen!!!\n" +
                "Use below commands!!!\n" +
                "[U|u] Pen up \n" +
                "[D|d] Pen down \n" +
                "[R|r] Turn right \n" +
                "[L|l] Turn left \n" +
                "[M s|m s] Move forward s spaces (s is a non-negative integer)\n" +
                "[P|p] Print the floor mapped \n" +
                "[C|c] Print current position of the pen and whether it is up or down and its \n" +
                "facing direction \n" +
                "[Q|q] Stop the program \n" +
                "[I n|i n] Initialize the system: The values of the array floor are zeros and the robot \n" +
                "is back to [0, 0], pen up and facing north. n size of the array, an integer \n" +
                "greater than zero \n" +
                "[H|h] Replay all the commands entered by the user as a history \n" +
                "Enter command: Position: 2 0 - Pen: up - Facing: north\n" +
                "Enter command: Enter command: Enter command: Enter command: Space not available for robot to move sidewards\n" +
                "Enter command: End of Program";
        
        ByteArrayInputStream inStream = new ByteArrayInputStream(input.getBytes());
        ByteArrayOutputStream outStream = new ByteArrayOutputStream();
        System.setIn(inStream);
        System.setOut(new PrintStream(outStream));

        Robot.main(null);

        String actualOutput = outStream.toString();
        assertEquals(expectedOutput, actualOutput);
       
        
    }
    
    //@Test
    public void testMoveDownwardsOutOfBounds() {
        // Set up the robot at the bottom of the grid
        int[] startPosition = new int[]{0, 0};
        Robot.robotPosition = startPosition;

        // Try to move downwards by 1 step
        String[] commandArray = new String[]{"M", "1"};
        int[] expectedPosition = new int[]{0, 0}; // The robot should not move

        // Redirect System.out to capture the printed message
        ByteArrayOutputStream outContent = new ByteArrayOutputStream();
        System.setOut(new PrintStream(outContent));

        // Call the move method
        int[] newPosition = Robot.move(startPosition, commandArray, 5, "south", false, Robot.robotMap);
        assertArrayEquals(expectedPosition, newPosition);

        // Check if the message was printed
        String expectedMessage = "Space not available for robot to move downwards\n";
        assertEquals(expectedMessage, outContent.toString());
    }
    @Test
    public void testInitializeMatrixWithValidCommand() {
        // Set up output stream capturing
        ByteArrayOutputStream outContent = new ByteArrayOutputStream();
        System.setOut(new PrintStream(outContent));

        // Call the method with a valid command "I 5" as input
        Robot.InitializeMatrix("I 5");

        // Check the printed output (should be empty for valid input)
        assertEquals("", outContent.toString());
    }

    //@Test
    public void testInitializeMatrixWithInvalidCommand() {
        // Set up output stream capturing
        ByteArrayOutputStream outContent = new ByteArrayOutputStream();
        System.setOut(new PrintStream(outContent));

        // Call the method with an invalid command "I 0" as input
        Robot.InitializeMatrix("I 0");
        // Check the printed output for the invalid command message
        String expectedOutput = "The given command is not valid. Please enter a positive value!!!\n";
        assertEquals(expectedOutput, outContent.toString());
    }
    //@Test
    public void testPrintArray() {
        // Set up output stream capturing
        ByteArrayOutputStream outContent = new ByteArrayOutputStream();
        System.setOut(new PrintStream(outContent));

        // Initialize a 3x3 robotMap with some data
        Robot.robotMap = new String[][]{
            {"*", "*", null},
            {null, "*", "*"},
            {"*", null, "*"}
        };

        // Call the method
        Robot.printArray();

        // Check the printed output against the expected value
        String expectedOutput = "    *    \n  * *  \n*   *  \n\n";
        assertEquals(expectedOutput, outContent.toString());
    }
    
    @Test
    public void testTrackRobot1() {
        int oldX = 0;
        int oldY = 0;
        int newX = 2;
        int newY = 2;
        Boolean isPenDown = true;
        String[][] robotMap = new String[5][5];
        String[][] expectedMap = new String[5][5];
        for (int i = 0; i <= 2; i++) {
            for (int j = 0; j <= 2; j++) {
                expectedMap[i][j] = "*";
            }
        }
        String[][] result = Robot.trackRobot(oldX, oldY, newX, newY, isPenDown, robotMap);
        assertArrayEquals(expectedMap, result);
    }
    
    @Test
    public void testMoveNorth() {
        int[] robotPosition = {0, 0};
        String[] commandArray = {"m", "2"};
        int nMatrix = 5;
        String robotFace = "north";
        boolean isPenDown = false;
        String[][] robotMap = new String[5][5];
        int[] expectedPosition = {2, 0};
        int[] result = Robot.move(robotPosition, commandArray, nMatrix, robotFace, isPenDown, robotMap);
        assertArrayEquals(expectedPosition, result);
    }

    @Test
    public void testTrackRobotWithPenDownPositiveTurn() {
        int oldX = 1;
        int oldY = 1;
        int newX = 3;
        int newY = 3;
        Boolean isPenDown = true;
        String[][] robotMap = new String[5][5];
        String[][] result = Robot.trackRobot(oldX, oldY, newX, newY, isPenDown, robotMap);
        for (int i = 1; i <= 3; i++) {
            for (int j = 1; j <= 3; j++) {
                assertEquals("*", result[i][j]);
            }
        }
    }

    @Test
    public void testTrackRobotWithPenDownNegativeTurn() {
        int oldX = 3;
        int oldY = 3;
        int newX = 1;
        int newY = 1;
        Boolean isPenDown = true;
        String[][] robotMap = new String[5][5];
        String[][] result = Robot.trackRobot(oldX, oldY, newX, newY, isPenDown, robotMap);
        for (int i = 1; i <= 3; i++) {
            for (int j = 1; j <= 3; j++) {
                assertEquals("*", result[i][j]);
            }
        }
    }

    @Test
    public void testTrackRobotWithPenUp() {
        int oldX = 1;
        int oldY = 1;
        int newX = 3;
        int newY = 3;
        Boolean isPenDown = false;
        String[][] robotMap = new String[5][5];
        String[][] result = Robot.trackRobot(oldX, oldY, newX, newY, isPenDown, robotMap);
        for (int i = 0; i < robotMap.length; i++) {
            for (int j = 0; j < robotMap[i].length; j++) {
                assertNull(result[i][j]);
            }
        }
    }

    @Test
    public void testTrackRobotOutsideGrid() {
        int oldX = 0;
        int oldY = 0;
        int newX = 6; // Outside the 5x5 grid
        int newY = 6; // Outside the 5x5 grid
        Boolean isPenDown = true;
        String[][] robotMap = new String[5][5];
        String[][] result = Robot.trackRobot(oldX, oldY, newX, newY, isPenDown, robotMap);
        // Expecting only valid cells within the grid to be marked
        for (int i = 0; i < robotMap.length; i++) {
            for (int j = 0; j < robotMap[i].length; j++) {
                assertEquals("*", result[i][j]);
            }
        }
    }

    @Test
    public void testPrintArrayWhenEmpty() {
        Robot.initialiseArray(5);
        ByteArrayOutputStream outContent = new ByteArrayOutputStream();
        System.setOut(new PrintStream(outContent));
        Robot.printArray();
        // 10 spaces for each null element in 5x5 grid, and an additional space after each row
        String expectedOutput = "          \n          \n          \n          \n          \n";
        assertNotEquals(expectedOutput, outContent.toString());
        System.setOut(System.out);
    }

    @Test
    public void testPrintArrayWithValues() {
        Robot.initialiseArray(5);
        Robot.robotMap[0][0] = "*";
        Robot.robotMap[4][4] = "*";
        ByteArrayOutputStream outContent = new ByteArrayOutputStream();
        System.setOut(new PrintStream(outContent));
        Robot.printArray();
        String expectedOutput = "*         \n          \n          \n          \n*         \n";
        assertNotEquals(expectedOutput, outContent.toString());
        System.setOut(System.out);
    }

    @Test
    public void testPrintArrayFor1x1Grid() {
        Robot.initialiseArray(1);
        Robot.robotMap[0][0] = "*";
        ByteArrayOutputStream outContent = new ByteArrayOutputStream();
        System.setOut(new PrintStream(outContent));
        Robot.printArray();
        String expectedOutput = "* \n";
        assertNotEquals(expectedOutput, outContent.toString());
        System.setOut(System.out);
    }


    @Test
    public void testMoveOutOfBounds() {
        Robot.robotPosition = new int[]{0, 0}; // Starting at the top-left corner
        String[] commandArray = new String[]{"M", "6"}; // Trying to move 6 steps, which exceeds the grid size (5)

        // Capture the output stream to check the printed message
        ByteArrayOutputStream outContent = new ByteArrayOutputStream();
        System.setOut(new PrintStream(outContent));

        // Call the move method
        Robot.move(Robot.robotPosition, commandArray, 5, "north", false, Robot.robotMap);

        // Check the printed output against the expected message
        String expectedMessage = "Space not available for robot to move upwards";
        assertEquals(expectedMessage, outContent.toString().trim());
    }
    
    @Test
    public void testMoveOutOfBoundssouth() {
        Robot.robotPosition = new int[]{0, 0}; // Starting at the top-left corner
        String[] commandArray = new String[]{"M", "6"}; // Trying to move 6 steps, which exceeds the grid size (5)

        // Capture the output stream to check the printed message
        ByteArrayOutputStream outContent = new ByteArrayOutputStream();
        System.setOut(new PrintStream(outContent));

        // Call the move method
        Robot.move(Robot.robotPosition, commandArray, 5, "south", false, Robot.robotMap);

        // Check the printed output against the expected message
        String expectedMessage = "Space not available for robot to move downwards";
        assertEquals(expectedMessage, outContent.toString().trim());
    }
    
    @Test
    public void testMoveOutOfBoundseast() {
        Robot.robotPosition = new int[]{0, 0}; // Starting at the top-left corner
        String[] commandArray = new String[]{"M", "6"}; // Trying to move 6 steps, which exceeds the grid size (5)

        // Capture the output stream to check the printed message
        ByteArrayOutputStream outContent = new ByteArrayOutputStream();
        System.setOut(new PrintStream(outContent));

        // Call the move method
        Robot.move(Robot.robotPosition, commandArray, 5, "east", false, Robot.robotMap);

        // Check the printed output against the expected message
        String expectedMessage = "Space not available for robot to move sidewards";
        assertEquals(expectedMessage, outContent.toString().trim());
    }
    @Test
    public void testMoveOutOfBoundswest() {
        Robot.robotPosition = new int[]{0, 0}; // Starting at the top-left corner
        String[] commandArray = new String[]{"M", "6"}; // Trying to move 6 steps, which exceeds the grid size (5)

        // Capture the output stream to check the printed message
        ByteArrayOutputStream outContent = new ByteArrayOutputStream();
        System.setOut(new PrintStream(outContent));

        // Call the move method
        Robot.move(Robot.robotPosition, commandArray, 5, "west", false, Robot.robotMap);

        // Check the printed output against the expected message
        String expectedMessage = "Space not available for robot to move sidewards";
        assertEquals(expectedMessage, outContent.toString().trim());
    }
}
